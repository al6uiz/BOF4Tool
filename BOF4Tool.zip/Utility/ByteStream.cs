﻿using System;
using System.Diagnostics;
using System.IO;

namespace JIT.ComponentModel
{
    [DebuggerStepThrough]
    public class ByteStream : MemoryStream
    {
        private ByteOrder _byteOrder = ByteOrder.BigEndian;
        private byte[] _cache = new byte[8];
        private bool _swap = BitConverter.IsLittleEndian;
        private byte[] _source;

        public ByteStream()
        {
            _byteOrder = ByteOrder.BigEndian;
            _swap = BitConverter.IsLittleEndian;
        }

        public ByteStream(byte[] source) : base(source)
        {
            _byteOrder = ByteOrder.BigEndian;
            _swap = BitConverter.IsLittleEndian;
            _source = source;
        }

        public ByteStream(byte[] buffer, ByteOrder byteOrder) : this(buffer)
        {
            ByteOrder = byteOrder;
        }

        public ByteStream(ByteOrder byteOrder)
        {
            ByteOrder = byteOrder;
        }

        private ByteOrder ByteOrder
        {
            get { return _byteOrder; }
            set
            {
                _byteOrder = value;
                _swap = (_byteOrder == ByteOrder.LittleEndian) != BitConverter.IsLittleEndian;
            }
        }

        public byte[] Source
        {
            get { return _source; }
        }

        public static byte[] GetBytes(byte value)
        {
            return new[] { value };
        }

        public static byte[] GetBytes(ushort value)
        {
            return new[] { (byte)(value >> 8), (byte)(value & 0xFF) };
        }

        public static byte[] GetBytes(int value)
        {
            return new[]
            {
                (byte)((value >> 24) & 0xFF),
                (byte)((value >> 16) & 0xFF),
                (byte)((value >> 8) & 0xFF),
                (byte)(value & 0xFF)
            };
        }

        public static byte[] GetBytes(ulong value)
        {
            return new[]
            {
                (byte)((value >> 56) & 0xFF),
                (byte)((value >> 48) & 0xFF),
                (byte)((value >> 40) & 0xFF),
                (byte)((value >> 32) & 0xFF),
                (byte)((value >> 24) & 0xFF),
                (byte)((value >> 16) & 0xFF),
                (byte)((value >> 8) & 0xFF),
                (byte)(value & 0xFF)
            };
        }

        public void Clear()
        {
            Position = 0L;

            var buffer = GetBuffer();

            Array.Clear(buffer, 0, buffer.Length);
        }

        public override int Read(byte[] buffer, int offset, int count)
        {
            var read = base.Read(buffer, offset, count);
            if (read != count)
            {
                throw new NotSupportedException();
            }

            return read;
        }

        public bool ReadBool()
        {
            return Convert.ToBoolean(ReadByte());
        }

        public new byte ReadByte()
        {
            var value = base.ReadByte();
            if (value < 0)
            {
                throw new NotSupportedException();
            }

            return (byte)value;
        }

        public sbyte ReadSByte()
        {
            var value = base.ReadByte();
            if (value < 0)
            {
                throw new NotSupportedException();
            }

            return (sbyte)value;
        }

        public byte[] ReadBytes(int count)
        {
            var buffer = new byte[count];
            Read(buffer, 0, count);

            return buffer;
        }

        public byte[] ReadToEnd()
        {
            return ReadBytes((int)(Length - Position));
        }

        public double ReadDouble()
        {
            if (_swap)
            {
                _cache[7] = ReadByte();
                _cache[6] = ReadByte();
                _cache[5] = ReadByte();
                _cache[4] = ReadByte();
                _cache[3] = ReadByte();
                _cache[2] = ReadByte();
                _cache[1] = ReadByte();
                _cache[0] = ReadByte();
            }
            else
            {
                Read(_cache, 0, 8);
            }

            return BitConverter.ToDouble(_cache, 0);
        }

        public void WriteUInt56(ulong value)
        {
            if (value > 0xFFFFFFFFFF)
            {
                throw new ArgumentOutOfRangeException(nameof(value));
            }

            if (ByteOrder == ByteOrder.BigEndian)
            {
                WriteByte((byte)(value >> 0x30));
                WriteUInt16((ushort)(value >> 0x20));
                WriteUInt32((uint)(value & 0xFFFFFFFF));
            }
            else
            {
                throw new NotImplementedException();
            }
        }

        public void WriteUInt40(ulong value)
        {
            if (value > 0xFFFFFFFFFF)
            {
                throw new ArgumentOutOfRangeException(nameof(value));
            }

            if (ByteOrder == ByteOrder.BigEndian)
            {
                WriteByte((byte)(value >> 0x20));
                WriteUInt32((uint)(value & 0xFFFFFFFF));
            }
            else
            {
                throw new NotImplementedException();
            }
        }

        public void WriteUInt24(uint value)
        {
            if (value > 0xFFFFFF)
            {
                throw new ArgumentOutOfRangeException(nameof(value));
            }

            if (ByteOrder == ByteOrder.BigEndian)
            {
                WriteByte((byte)(value >> 16));
                WriteUInt16((ushort)(value & 0xFFFF));
            }
            else
            {
                throw new NotImplementedException();
            }
        }

        public short ReadInt16()
        {
            return (short)ReadUInt16();
        }

        public int ReadInt32()
        {
            return (int)ReadUInt32();
        }

        public long ReadInt64()
        {
            return (long)ReadUInt64();
        }

        public float ReadSingle()
        {
            if (_swap)
            {
                _cache[3] = ReadByte();
                _cache[2] = ReadByte();
                _cache[1] = ReadByte();
                _cache[0] = ReadByte();
            }
            else
            {
                _cache[0] = ReadByte();
                _cache[1] = ReadByte();
                _cache[2] = ReadByte();
                _cache[3] = ReadByte();
            }

            return BitConverter.ToSingle(_cache, 0);
        }

        public uint ReadUInt24()
        {
            if (_byteOrder == ByteOrder.BigEndian)
            {
                return (uint)((ReadByte() << 16) | (ReadByte() << 8) | ReadByte());
            }

            return (uint)(ReadByte() | (ReadByte() << 8) | (ReadByte() << 16));
        }

        public ushort ReadUInt16()
        {
            if (_byteOrder == ByteOrder.BigEndian)
            {
                return (ushort)((ReadByte() << 8) | ReadByte());
            }

            return (ushort)(ReadByte() | (ReadByte() << 8));
        }

        public uint ReadUInt32()
        {
            if (_byteOrder == ByteOrder.BigEndian)
            {
                return (uint)((((ReadByte() << 0x18) | (ReadByte() << 0x10)) | (ReadByte() << 8)) | ReadByte());
            }
            else
            {
                return (uint)(((ReadByte() | (ReadByte() << 8)) | (ReadByte() << 0x10)) | (ReadByte() << 0x18));
            }
        }

        public ulong ReadUInt40()
        {
            if (_byteOrder == ByteOrder.BigEndian)
            {
                return ((ulong)ReadByte() << 0x20) | (uint)((((ReadByte() << 0x18) | (ReadByte() << 0x10)) | (ReadByte() << 8)) | ReadByte());
            }
            else
            {
                return (uint)(((ReadByte() | (ReadByte() << 8)) | (ReadByte() << 0x10)) | (ReadByte() << 0x18)) | ((ulong)ReadByte() << 0x20);
            }
        }

        public ulong ReadUInt64()
        {
            uint first;
            uint last;
            if (_byteOrder == ByteOrder.BigEndian)
            {
                first = (uint)((((ReadByte() << 0x18) | (ReadByte() << 0x10)) | (ReadByte() << 8)) | ReadByte());
                last = (uint)((((ReadByte() << 0x18) | (ReadByte() << 0x10)) | (ReadByte() << 8)) | ReadByte());
            }
            else
            {
                last = (uint)(((ReadByte() | (ReadByte() << 8)) | (ReadByte() << 0x10)) | (ReadByte() << 0x18));
                first = (uint)(((ReadByte() | (ReadByte() << 8)) | (ReadByte() << 0x10)) | (ReadByte() << 0x18));
            }

            return (((ulong)first << 0x20) | last);
        }

        public ulong ReadUInt48()
        {
            uint first;
            uint last;

            if (_byteOrder == ByteOrder.BigEndian)
            {
                first = ReadUInt16();
                last = ReadUInt32();
            }
            else
            {
                last = ReadUInt32();
                first = ReadUInt16();
            }

            return (((ulong)first << 0x20) | last);
        }

        public ulong ReadUInt56()
        {
            uint first;
            uint last;

            if (_byteOrder == ByteOrder.BigEndian)
            {
                first = ReadUInt24();
                last = ReadUInt32();
            }
            else
            {
                last = ReadUInt32();
                first = ReadUInt24();
            }

            return (((ulong)first << 0x20) | last);
        }

        public void WriteBytes(byte[] data)
        {
            WriteBytes(data, 0, data.Length);
        }

        public void WriteBytes(byte[] data, int offset, int length)
        {
            Write(data, offset, length);
        }

        public void WriteBool(bool value)
        {
            base.WriteByte(Convert.ToByte(value));
        }

        public void WriteSByte(sbyte value)
        {
            WriteByte((byte)value);
        }

        public void WriteInt16(short value)
        {
            WriteUInt16((ushort)value);
        }

        public void WriteInt32(int value)
        {
            WriteUInt32((uint)value);
        }

        public void WriteInt64(long value)
        {
            WriteUInt64((ulong)value);
        }

        public void WriteUInt16(ushort value)
        {
            if (_byteOrder == ByteOrder.BigEndian)
            {
                base.WriteByte((byte)(value >> 8));
                base.WriteByte((byte)value);
            }
            else
            {
                base.WriteByte((byte)value);
                base.WriteByte((byte)(value >> 8));
            }
        }

        public void WriteUInt32(uint value)
        {
            if (_byteOrder == ByteOrder.BigEndian)
            {
                _cache[3] = (byte)value;
                _cache[2] = (byte)(value >> 8);
                _cache[1] = (byte)(value >> 0x10);
                _cache[0] = (byte)(value >> 0x18);
            }
            else
            {
                _cache[0] = (byte)value;
                _cache[1] = (byte)(value >> 8);
                _cache[2] = (byte)(value >> 0x10);
                _cache[3] = (byte)(value >> 0x18);
            }

            Write(_cache, 0, 4);
        }

        public void WriteUInt64(ulong value)
        {
            if (_byteOrder == ByteOrder.BigEndian)
            {
                _cache[7] = (byte)value;
                _cache[6] = (byte)(value >> 0x08);
                _cache[5] = (byte)(value >> 0x10);
                _cache[4] = (byte)(value >> 0x18);
                _cache[3] = (byte)(value >> 0x20);
                _cache[2] = (byte)(value >> 0x28);
                _cache[1] = (byte)(value >> 0x30);
                _cache[0] = (byte)(value >> 0x38);
            }
            else
            {
                _cache[0] = (byte)value;
                _cache[1] = (byte)(value >> 0x08);
                _cache[2] = (byte)(value >> 0x10);
                _cache[3] = (byte)(value >> 0x18);
                _cache[4] = (byte)(value >> 0x20);
                _cache[5] = (byte)(value >> 0x28);
                _cache[6] = (byte)(value >> 0x30);
                _cache[7] = (byte)(value >> 0x38);
            }

            Write(_cache, 0, 8);
        }

        public void WriteDouble(double value)
        {
            var bytes = BitConverter.GetBytes(value);
            if (_swap)
            {
                _cache[0] = bytes[7];
                _cache[1] = bytes[6];
                _cache[2] = bytes[5];
                _cache[3] = bytes[4];
                _cache[4] = bytes[3];
                _cache[5] = bytes[2];
                _cache[6] = bytes[1];
                _cache[7] = bytes[0];

                Write(_cache, 0, 8);
            }
            else
            {
                Write(bytes, 0, 8);
            }
        }

        public void WriteSingle(float value)
        {
            var bytes = BitConverter.GetBytes(value);

            if (_swap)
            {
                _cache[0] = bytes[3];
                _cache[1] = bytes[2];
                _cache[2] = bytes[1];
                _cache[3] = bytes[0];
                Write(_cache, 0, 4);
            }
            else
            {
                Write(bytes, 0, 4);
            }
        }
    }

    public enum ByteOrder
    {
        BigEndian,
        LittleEndian
    }

    [DebuggerStepThrough]
    public static class StreamExtension
    {
        public static void WriteBytes(this Stream s, byte[] value)
        {
            s.Write(value, 0, value.Length);
        }

        public static byte[] ReadToEnd(this Stream s)
        {
            var remain = (int)(s.Length - s.Position);

            return ReadBytes(s, remain);
        }

        public static byte[] ReadBytes(this Stream s, int length)
        {
            var buffer = new byte[length];

            s.Read(buffer, 0, length);

            return buffer;
        }
    }
}